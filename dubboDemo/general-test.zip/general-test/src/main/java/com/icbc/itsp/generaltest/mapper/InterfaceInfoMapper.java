package com.icbc.itsp.generaltest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.icbc.itsp.generaltest.entity.InterfaceInfo;

import java.util.List;

public interface InterfaceInfoMapper extends BaseMapper<InterfaceInfo> {
    List<InterfaceInfo> query(InterfaceInfo interfaceInfo);
}
