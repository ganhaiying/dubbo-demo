package com.icbc.itsp.generaltest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.icbc.itsp.generaltest.entity.InterfaceInfo;

import java.util.List;

public interface InterfaceInfoService extends IService<InterfaceInfo> {
    List<InterfaceInfo> query(InterfaceInfo interfaceInfo);
}
