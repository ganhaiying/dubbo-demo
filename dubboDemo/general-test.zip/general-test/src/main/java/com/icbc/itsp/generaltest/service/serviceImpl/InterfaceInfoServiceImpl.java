package com.icbc.itsp.generaltest.service.serviceImpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.icbc.itsp.generaltest.entity.InterfaceInfo;
import com.icbc.itsp.generaltest.mapper.InterfaceInfoMapper;
import com.icbc.itsp.generaltest.service.InterfaceInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class InterfaceInfoServiceImpl extends ServiceImpl<InterfaceInfoMapper, InterfaceInfo> implements InterfaceInfoService {
    @Resource
    private InterfaceInfoMapper interfaceInfoMapper;

    @Override
    public List<InterfaceInfo> query(InterfaceInfo interfaceInfo){
        List<InterfaceInfo> list = interfaceInfoMapper.query(interfaceInfo);
        return list;
    }
}
