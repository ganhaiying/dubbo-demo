package com.icbc.itsp.generaltest.controller;

import com.icbc.itsp.generaltest.entity.InterfaceInfo;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "interfaceInfo")
public class InterfaceInfoController {

    @RequestMapping(value = "/query")
    public Object query(InterfaceInfo interfaceInfo){
        return "";
    }
}
