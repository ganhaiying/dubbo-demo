package com.icbc.itsp.generaltest.entity;

import java.io.Serializable;

public class InterfaceInfo implements Serializable {
    private int id ;
    private String version;
    private String interfaceEnName;
    private String interfaceChName;
}
