package com.icbc.itsp.generaltest;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple StartGeneralTest.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
